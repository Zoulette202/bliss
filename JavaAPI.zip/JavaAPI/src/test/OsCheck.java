package test;

import java.io.File;
import java.lang.management.ManagementFactory;
import java.lang.management.OperatingSystemMXBean;
import java.lang.reflect.Method;
import java.lang.reflect.Modifier;
import java.lang.Math;

import javax.ws.rs.GET;
import javax.ws.rs.POST;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.Produces;
import javax.ws.rs.QueryParam;
import javax.ws.rs.core.MediaType;

import javax.ws.rs.ApplicationPath;
import javax.ws.rs.core.Application;

@Path("/machine")
public class OsCheck {
	
	// http://localhost:8080/JavaAPI/rest/machine
	@GET
	@Produces(MediaType.TEXT_PLAIN)
	public String sayPlainTextHello() {
		return "Hello OsCheck";
	}
	
	private static final long MEGABYTE = 1024L * 1024L;	
	public long diskSize; 
	public String userName;  
	public long maxMemory; 
	public long memorySize;
	public long availableProcessors; 
	public long freePhysicalMemorySize; 
	public Runtime runtime; 
	public long freeMemory; 
	public long totalMemory; 
	public long memory; 

	public OsCheck() {
		this.diskSize = (long) (new File("/").getTotalSpace() * (Math.pow(10, -9)));
		this.userName = System.getProperty("user.name"); 
		this.maxMemory = Runtime.getRuntime().maxMemory(); 
		this.memorySize = (long) (((com.sun.management.OperatingSystemMXBean) ManagementFactory.getOperatingSystemMXBean()).getTotalPhysicalMemorySize() * (Math.pow(10, -9)));
		this.availableProcessors = ((com.sun.management.OperatingSystemMXBean) ManagementFactory.getOperatingSystemMXBean()).getAvailableProcessors();
		this.freePhysicalMemorySize = (long) (((com.sun.management.OperatingSystemMXBean) ManagementFactory.getOperatingSystemMXBean()).getFreePhysicalMemorySize() * (Math.pow(10, -9)));
		this.runtime = Runtime.getRuntime();
		this.freeMemory =  this.runtime.freeMemory();
		this.totalMemory =  this.runtime.totalMemory(); 
		this.memory = runtime.totalMemory() - runtime.freeMemory();
	}
	
	public static void printUsage() {
		  OperatingSystemMXBean operatingSystemMXBean = ManagementFactory.getOperatingSystemMXBean();
		  for (Method method : operatingSystemMXBean.getClass().getDeclaredMethods()) {
		    method.setAccessible(true);
		    if (method.getName().startsWith("get")
		        && Modifier.isPublic(method.getModifiers())) {
		            Object value;
		        try {
		            value = method.invoke(operatingSystemMXBean);
		        } catch (Exception e) {
		            value = e;
		        }
		        System.out.println(method.getName() + " = " + value);
		    } 
		  } 
	}
	
	public static void printRAMandDiskSize() {   
		OsCheck os = new OsCheck();
        System.out.println("Size of C: = "+ os.diskSize+" Go");
        System.out.println("User Name = "+ os.userName);

        System.out.println("RAM Size = "+ os.memorySize+" Go");

        System.out.println("Total memory : "+ os.totalMemory);
       System.out.println("Free memory : "+ os.freeMemory);
        System.out.println("Used memory is bytes: " + os.memory);
//        System.out.println("Used memory is megabytes: "
//                + bytesToMegabytes(memory)); 
        
        System.out.println("Free physical memory size is : "+ os.freePhysicalMemorySize+" Go");
        System.out.println("AvailableProcessors : "+ os.availableProcessors); 
	}
	
	public static void main(String[] argrs) {
//		printUsage();
		printRAMandDiskSize();
		
//		printRAMUsage();
	}
	
	/*	Fonction permettant de créer l'URL qui sera utilisatée par le Web Service
	*/
// http://localhost:8080/JavaAPI/rest/machine?nom_utilisateur=alhas	
	@GET 
	@Produces(MediaType.TEXT_HTML)
	public String displayMachineInfos(@QueryParam("nom_utilisateur") String nom_utilisateur) {
		String reponse; 
		String taille_mem, taille_ram; 
		if(nom_utilisateur.equals(this.userName)) {
			reponse = "La taille de la memoire de l'utilisateur " +this.userName+ " est : "+ this.diskSize;
		}
		
		else {
			reponse = "Ce nom d'utilisateur n'est pas connu";
		}
		
		return "<html>" + "<title>" + "Informations de la machine " + "</title>"
						+ "<body>" + reponse +"</body>" + "</html>"; 
	}
	
}